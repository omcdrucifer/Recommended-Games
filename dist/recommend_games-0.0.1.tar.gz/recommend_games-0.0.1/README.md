PYTHON RECOMMENDATION ENGINE

The next portfolio project for CS Certification on Codecademy.

This one is a recommendation engine, intended to give suggestions to a user based on inputs.

I have chosen to make a video game recommendation engine that will return a list of games based on genre
and ranked by their MetaCritic ratings.

This will be an interactive terminal app, similar to the previous, but will use graphs, vertices, and BFS.

Currently I have the vertex/graph/bfs methods defined, with some examples to test the features. 

I decided to separate the portfolio projects rather than dump them all into one repo to make it easier to parse files.

I now have a base line for all files except the print statements. Once I get a template for those I will flesh everything out.

I will likely incorporate logging as I did in the previous project as well. 

12-13-24

At this point the app is feature complete. It is just a small proof of concept that may contribute toward a larger
personal portfolio project I am still conceptualizing.

I will be putting it to PyPI as well. 
